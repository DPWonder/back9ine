import { motion, AnimatePresence } from 'framer-motion';
import { useState, useEffect } from 'react';

const words = [
  "Resilience",
  "Excellence",
  "Leadership",
  "Passion",
  "Purpose"
];

export default function DynamicTagline() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsVisible(false);
      setTimeout(() => {
        setCurrentIndex((prev) => (prev + 1) % words.length);
        setIsVisible(true);
      }, 500);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <h1 className="font-display text-5xl md:text-7xl font-bold mb-8 tracking-tight">
      Where Golf Meets{' '}
      <AnimatePresence mode="wait">
        <motion.span
          key={currentIndex}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="inline-block text-premium-gold"
        >
          {words[currentIndex]}
        </motion.span>
      </AnimatePresence>
    </h1>
  );
}