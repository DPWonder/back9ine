/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      colors: {
        'golf-green': '#2C5530',
        'fairway': '#8DAF7C',
        'sand': '#E5D7B5',
        'premium-gold': '#D4AF37',
      },
      fontFamily: {
        sans: ['Inter var', 'system-ui', 'sans-serif'],
        display: ['Druk Wide Bold', 'system-ui', 'sans-serif'],
      },
      backgroundImage: {
        'hero-pattern': "url('/images/golf-course-hero.jpg')",
      },
    },
  },
  plugins: [],
}